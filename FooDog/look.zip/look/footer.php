<?php
/**
 * look created by ThemeRuby
 * this file render footer of theme
 */
get_template_part( 'templates/section', 'footer' );
?>
</div><!--#main site wrap-->
</div><!--#main site outer-->
<?php wp_footer(); ?>
</body>
</html>