<?php

//including ruby page composer
require_once get_template_directory() . '/includes/composer/composer_enqueue.php';
require_once get_template_directory() . '/includes/composer/composer_setup.php';
require_once get_template_directory() . '/includes/composer/composer_config.php';
require_once get_template_directory() . '/includes/composer/composer_action.php';
require_once get_template_directory() . '/includes/composer/composer_render.php';
require_once get_template_directory() . '/includes/composer/composer_block.php';