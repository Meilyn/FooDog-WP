<div class="top-footer-wrap">
	<div class="top-footer-inner">
		<?php if ( is_active_sidebar( 'look_ruby_sidebar_footer_fullwidth' ) )  : ?>
			<?php dynamic_sidebar( 'look_ruby_sidebar_footer_fullwidth' ); ?>
		<?php endif; ?>
	</div>
</div><!--#top footer-->