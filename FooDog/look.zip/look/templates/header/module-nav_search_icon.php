<div class="nav-search-wrap">
	<a href="#" id="ruby-nav-search" data-mfp-src="#ruby-banner-search-form" data-effect="mpf-ruby-effect" title="<?php esc_attr_e('search', 'look'); ?>" class="banner-search-icon">
		<i class="fa fa-search"></i>
	</a><!--#nav search button-->
</div>