<div class="off-canvas-btn-wrap">
	<div class="off-canvas-btn">
		<a href="#" class="ruby-trigger" title="off canvas button">
			<span class="icon-wrap"></span>
		</a>
	</div><!--button show menu mobile-->
</div>
