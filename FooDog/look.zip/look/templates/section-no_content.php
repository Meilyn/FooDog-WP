<div id="main-content-wrap" class="row clearfix">
	<div class="ruby-container">
		<div class="search-no-result post-title">
			<h3><?php esc_html_e( 'Oops! It looks like nothing was found for this query', 'look' ); ?></h3>
		</div>
	</div>
</div>
